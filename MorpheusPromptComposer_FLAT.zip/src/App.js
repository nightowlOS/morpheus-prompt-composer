import React from 'react';
import './styles/App.css';
import PromptBuilder from './components/PromptBuilder';

function App() {
  return (
    <div className="App">
      <h1>🧬 Morphē Prompt Composer</h1>
      <PromptBuilder />
    </div>
  );
}

export default App;