import React, { useState, useEffect } from 'react';

const modules = {
  "Kamera-Modul": ["cinematic composition", "70mm film", "anamorphic lens", "shallow depth of field", "rule of thirds"],
  "Licht-Modul": ["chiaroscuro", "volumetric lighting", "rim lighting", "god rays"],
  "Stil-Modul": ["ritualistic biopunk", "hard sci-fi", "Giger", "Beksiński", "Syd Mead"],
  "Render-Modul": ["photorealistic", "ultra-detailed", "8K", "PBR", "crisp focus"]
};

const presets = {
  "Architekt": {
    "Kamera-Modul": ["cinematic composition", "anamorphic lens"],
    "Licht-Modul": ["chiaroscuro", "volumetric lighting"],
    "Stil-Modul": ["ritualistic biopunk", "Giger"],
    "Render-Modul": ["photorealistic", "8K"]
  },
  "Klinge": {
    "Kamera-Modul": ["shallow depth of field", "rule of thirds"],
    "Licht-Modul": ["rim lighting", "god rays"],
    "Stil-Modul": ["hard sci-fi", "Beksiński"],
    "Render-Modul": ["crisp focus", "PBR"]
  }
};

function PromptBuilder() {
  const [selected, setSelected] = useState({});
  const [prompt, setPrompt] = useState("");
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const stored = localStorage.getItem("morpheus_prompt_history");
    if (stored) setHistory(JSON.parse(stored));
  }, []);

  useEffect(() => {
    localStorage.setItem("morpheus_prompt_history", JSON.stringify(history));
  }, [history]);

  const handleToggle = (category, item) => {
    const current = selected[category] || [];
    const updated = current.includes(item)
      ? current.filter(i => i !== item)
      : [...current, item];
    setSelected({ ...selected, [category]: updated });
  };

  const generatePrompt = () => {
    const parts = Object.values(selected).flat();
    const result = parts.join(", ");
    setPrompt(result);
    setHistory([result, ...history.slice(0, 9)]);
  };

  const exportPrompt = () => {
    const blob = new Blob([prompt], { type: 'text/plain;charset=utf-8' });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "morpheus_prompt.txt";
    link.click();
  };

  const loadPreset = (name) => {
    setSelected(presets[name]);
  };

  return (
    <div>
      <h2>🎭 Presets</h2>
      {Object.keys(presets).map(name => (
        <button key={name} onClick={() => loadPreset(name)}>{name}</button>
      ))}
      {Object.entries(modules).map(([category, items]) => (
        <div key={category}>
          <h3>{category}</h3>
          {items.map(item => (
            <label key={item} style={{ display: "block" }}>
              <input
                type="checkbox"
                onChange={() => handleToggle(category, item)}
                checked={selected[category]?.includes(item) || false}
              />
              {item}
            </label>
          ))}
        </div>
      ))}
      <button onClick={generatePrompt}>🧪 Prompt generieren</button>
      <textarea value={prompt} readOnly rows={5} style={{ width: "100%", marginTop: "1rem" }} />
      <button onClick={exportPrompt}>📁 Prompt exportieren</button>
      {history.length > 0 && (
        <div style={{ marginTop: "2rem" }}>
          <h3>🧠 Prompt-Verlauf</h3>
          <ul>
            {history.map((p, i) => <li key={i} style={{ fontSize: "0.9rem" }}>{p}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
}

export default PromptBuilder;